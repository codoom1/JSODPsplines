# JSODPsplines 0.1.0

* Initial CRAN submission.
* Implemented resub method for derivative estimation using P-splines.
* Added functions for penalized spline estimation, oracle estimation, and optimization of smoothing parameters.
* Included examples and vignettes to demonstrate package functionality.