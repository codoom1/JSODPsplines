library(testthat)
library(JSODPsplines)

test_check("JSODPsplines")